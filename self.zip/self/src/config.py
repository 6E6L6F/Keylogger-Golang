class Config:
    api_id = '16628384'
    api_hash = 'a42b7a458a41ca52f7812a52f76bc561'
    phone = '+2349068058103'