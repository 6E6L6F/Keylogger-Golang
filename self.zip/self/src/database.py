import sqlite3
class Database:
    def __init__(self) -> None:
        self.databse = sqlite3.connect(
            "database.sqlite3"
        )
        self.cur = self.databse.cursor()
        self.cur.execute(
            "CREATE TABLE IF NOT EXISTS channels(link)"
        )
        self.databse.commit()
        
    
    def write_channel(self , username):
        self.cur.execute(
            "INSERT INTO channels(link) VALUES(?)" , (username,)
        )
        self.databse.commit()
        
    def get_channel(self):
        result = self.cur.execute(
            "SELECT * FROM channels"
        ).fetchall()
        return result
    