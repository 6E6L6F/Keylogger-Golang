apt install python3
apt install python3-pip
apt install tor
apt install proxychains4
pip install -r ../req.txt --break-system-packages
systemctl start tor
