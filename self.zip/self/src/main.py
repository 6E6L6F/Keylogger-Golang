from telethon import TelegramClient, events, functions,types
from database import Database
from config import Config

admin_id = 1769267646

client = TelegramClient('session_name', Config.api_id, Config.api_hash)
database = Database()
channel_links = []
comment_text = 0

monitoring_active = False

async def add_and_join_channels(links):
    global channel_links
    for link in links:
        try:
            channel = await client.get_entity(link[0])
            await client(functions.channels.JoinChannelRequest(channel))
            channel_links.append(channel)
        except Exception as e:
            print(f'{str(e)}')

async def monitor_channels():
    global monitoring_active
    monitoring_active = True

    @client.on(events.NewMessage(chats=channel_links))
    async def new_post_handler(event):
        try:
            await client(functions.messages.SendMessageRequest(
                peer=event.chat,
                message=comment_text,
                reply_to_msg_id=event.message.id
            ))
            print(f'{event.message.id}')
        except Exception as e:
            print(f'{str(e)}')

@client.on(events.NewMessage)
async def handle_command(event):
    global monitoring_active, comment_text
    if event.sender_id == admin_id:
        if event.message.message.lower() == 'start':
            monitoring_active = True
            await event.reply('لطفاً متن کامنت را وارد کنید:')
        
        elif monitoring_active and comment_text == 0:
            comment_text = event.message.message
            await event.reply('نظارت بر پست‌های جدید آغاز شد.')
            await monitor_channels()
    

async def main():
    await client.start(Config.phone)

    links = database.get_channel()
    await add_and_join_channels(links)

    await client.run_until_disconnected()

with client:
    client.loop.run_until_complete(main())


