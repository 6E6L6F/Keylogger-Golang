from telethon import TelegramClient, functions
from telethon.tl.types import Channel
from database import Database
from time import sleep
from random import randint
api_id = '16628384'
api_hash = 'a42b7a458a41ca52f7812a52f76bc561'
phone = ''

client = TelegramClient('session_name', api_id, api_hash )
app = Database()
count = 0
async def search_and_join_channels(keyword):
    global count
    await client.start(phone)

    result = await client(functions.contacts.SearchRequest(
        q=keyword,
        limit=1000
    ))

    for user in result.chats:
        if isinstance(user, Channel):            
            try:
                await client(functions.channels.JoinChannelRequest(user))
            except Exception as e:
                print(e)

            try:
                full_channel = await client(functions.channels.GetFullChannelRequest(
                    channel=user
                ))
                
                if full_channel.full_chat.linked_chat_id:
                    app.write_channel(user.username)
                    count += 1
            except Exception as e:
                print(str(e))
            
            try:
                await client(functions.channels.LeaveChannelRequest(user))

            except Exception as e:
                print(str(e))
    print(f"joined channel : {count}")
    sleep(randint(10,60))

text = ['دولت' , 'رسانه' , 'اهنگ' , 'موزیک' , 'برنامه نویسی' , 'پایتون' , 'پی اچ پی' , 'حرفه ای' , 'سوپر' , 'جق' , 'کصشر' , 'ایرانی' , 'خارجی' , 'فیلم']
for i in text:
    with client:
        client.loop.run_until_complete(search_and_join_channels(i))